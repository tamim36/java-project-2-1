package eye.in.the.sky;



public class bomb extends Elements {
	public int bomb_num;
	public bomb(int x,int y,int num) {
		super(x, y);
		bomb_num=num;
		//initbomb();	
	}
	

    
    
   /* private void initbomb() {
        
        loadImage("/bomb.png");
        getImageDimensions();        
    }*/

   /* public void move() {
        
        x += bomb_SPEED;
        
        if (x > BOARD_WIDTH)
            visible = false;
    }*/

}
