package eye.in.the.sky;

public class ScoreData {
Integer score;
String name;

public ScoreData( String name , Integer score) {
this.name=name;
this.score=score;

}

}
