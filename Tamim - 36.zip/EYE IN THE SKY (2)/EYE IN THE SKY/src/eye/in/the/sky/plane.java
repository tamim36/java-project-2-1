package eye.in.the.sky;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.Toolkit;
import java.awt.event.KeyEvent;
import java.util.ArrayList;
import java.util.List;

import javax.swing.JPanel;

public class plane extends JPanel {
	
	private final String fileGenieImage = "/jet.png",
			fileGenieFireImage = "/jet.png",
			fileBackGround = "/geniebg.png";
	private int width = 180, height =5000 ;	
	public int positionY;
	private Image genieImage, genieFireImage;
	private int  imagePosY;
	private  int dx=0;
	public  int getPositionY() {
		return dx+150;
	}
	public static void setPositionY(int positionY) {
		positionY = positionY;
	}



	public int getDx() {
		return dx;
	}
	public void setDx(int dx) {
		this.dx = dx;
	}
	public int getDy() {
		return dy+47;
	}
	public void setDy(int dy) {
		this.dy = dy;
	}



	private int dy=00;
	private double angle;
	private static boolean fire;
	private boolean isAlive=true;
	public static List<bomb> arrow;
	
	
	public plane() {	
		   arrow = new ArrayList<>();
		//positionY = 330 ;
		
		setBounds(dx, dy, width, height);
		//setOpaque(true);
		//setBackground(Color.white); 
		//setOpaque(true);
		setBackground(new Color(0, 0, 0, 0 )); 
		setFire(false,0,0);
		setImages();
	}
	private void setImages() {
		genieImage = Toolkit.getDefaultToolkit().getImage(getClass().getResource("/jet.png"));
		genieFireImage = Toolkit.getDefaultToolkit().getImage(getClass().getResource("/jet.png"));
		
		//imagePosY = (height / 2) - (genieImage.getHeight(null) / 2) - 15;
		//System.out.println(""+imagePosY);
		imagePosY=20;
		angle = 0;
	}
	public static void setFire(boolean f,int x,int y) {
		fire = f;
		if(fire)
		{
		//arrow.add(new bomb(x,y));
		//System.err.println(""+"clicked");
		}
	}
	public void rotate(int x, int y, boolean fire) {
		setFire(fire,0,0);
		angle = Math.atan2(y - (positionY + imagePosY), x);
		repaint();
	}
	@Override
	public void paint(Graphics g) {
		super.paint(g);
		Graphics2D g2d = (Graphics2D) g;
		//g2d.rotate(angle, 15, imagePosY + 60);
		
			g2d.drawImage(genieImage, dx, dy, null);
		
			
	}
	//@Override
	protected void paintComponent(Graphics g) {
		super.paintComponent(g);
		/*if(Game.level%2==0)
		g.drawImage(Toolkit.getDefaultToolkit().getImage(getClass().getResource("/geniebg.png")), 0, 0, null);*/
		
	}
	public void keyPressed(KeyEvent e) {

        int key = e.getKeyCode();

        if (key == KeyEvent.VK_SPACE) {
        	setFire(isAlive,0, 0);
        }

        if (key == KeyEvent.VK_A) {
            dx -= -4;
        }

        if (key == KeyEvent.VK_D) {
            dx += 4;
        }

        if (key == KeyEvent.VK_W) {
            dy  -= 4;
        }

        if (key == KeyEvent.VK_S) {
            dy += 4;
        }
    	//setBounds(dx, dy, width, height);
    	repaint();
    }

    

    public void keyReleased(KeyEvent e) {

        int key = e.getKeyCode();

        if (key == KeyEvent.VK_A) {
            dx = 0;
        }

        if (key == KeyEvent.VK_D) {
            dx = 0;
        }

        if (key == KeyEvent.VK_W) {
            dy = 0;
        }

        if (key == KeyEvent.VK_S) {
            dy = 0;
        }
    	//setBounds(dx, dy, width, height);
    }
	
}