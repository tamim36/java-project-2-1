package eye.in.the.sky;

import java.awt.HeadlessException;
import java.io.IOException;

import javax.swing.JOptionPane;

public class Main {
	
	public static void main(String[] args) {
		
		try {
			new Game().startGame();
		} catch (Exception e) {
		
		}
	}
}
