package eye.in.the.sky;

public class Asset {

}
